import './style.css'






const map = L.map('map').setView([45.4613, 9.1595], 4);
 
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
}).addTo(map);


function colore(mag) {
  if(mag > 6)
    return "red";
  else if(mag>4) {
    return "orange"
  }
  return "yellow"
}

//const marker = L.marker([45.54.1553, 10.211802]).addTo(map);
 
fetch("https:earthquake.usgs.gov/earthquakes/feed/v1.0/summary/1.0_month.geojson")
  .then(r => r.json())
  .then(body =>{
    const terremoti = body.features
    console.log(terremoti)
    for(const terremoto of terremoti){
      const lat = terremoto.geometry.coordinates[1]
      const lng = terremoto.geometry.coordinates[0]
      const mag = terremoto.properties.mag
      const place = terremoto.properties.place
      L.circle([lat, lng],  {
        color: colore(mag),
        fillColor: colore(mag),
        fillOpacity: 0.5,
        radius: Math.pow(10,mag)/10
      }).addTo(map);
    }
  })

L.marker([40.80204965726588, 19.9169125917972]).addTo(map)
    .bindPopup('Casa dei miei nonni :)')
    ;

L.marker([45.548506244450266, 10.07522941199582]).addTo(map)
    .bindPopup('Casa mia :)')
    ;

var polygon = L.polygon([
    [37.979176717314445, 12.36414706447107],
    [38.250568446000216, 15.574032607364728],
    [36.68979916669328, 15.023082103747385]
]).addTo(map)    .bindPopup('la sicilia');

var greenIcon = L.icon({
    iconUrl: 'Senzatitolo.jpg',
    

    iconSize:     [150, 60], // size of the icon
    shadowSize:   [50, 64], // size of the shadow
    iconAnchor:   [22, 94], // point of the icon which will correspond to marker's location
    shadowAnchor: [4, 62],  // the same for the shadow
    popupAnchor:  [-3, -76] // point from which the popup should open relative to the iconAnchor
});

L.marker([51.5, -0.09], {icon: greenIcon}).addTo(map) .bindPopup('whattaspp');

var videoUrls = [
    'elefants.mp4'
];
var errorOverlayUrl = 'https://cdn-icons-png.flaticon.com/512/110/110686.png';
var latLngBounds = L.latLngBounds([[28.250762086236037, -7.160621090048437], [11.113461025399914, 31.276081783292284]]);

var videoOverlay = L.videoOverlay(videoUrls, latLngBounds, {
    opacity: 1,
    errorOverlayUrl: errorOverlayUrl,
    interactive: true,
    autoplay: true,
    muted: true,
    playsInline: true
}).addTo(map) .bindPopup('piiiiiiiiiiiii')

var popup = L.popup();

function onMapClick(e) {
  L.point(e.latlng.lat, e.latlng.lng)
  var elefanti = true
    popup
        .setLatLng(e.latlng)
        .setContent("You clicked the map at " + e.latlng.toString())
        .openOn(map),
        fetch("http://127.0.0.1:8090/api/collections/coordinate/records",{
    method:"POST",
    body: JSON.stringify({
      x: e.latlng.lat,
      y: e.latlng.lng,
      elefante: elefanti
    }),
    headers:{
      "Content-type":"application/json"
    }
  });
}

map.on('click', onMapClick);








const response = await fetch("http://127.0.0.1:8090/api/collections/appunti/records")
const data = await response.json()

console.log(data.item)


const postTest = document.getElementById("postTest")

